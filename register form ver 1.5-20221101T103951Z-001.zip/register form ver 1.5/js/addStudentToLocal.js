function addStudentToLocal() {
console.log('running addStudentToLocal()')
    let fullName = document.getElementById('fullName').value
    let email = document.getElementById('email').value
    let phone = document.getElementById('phone').value
    let sexual = document.getElementById('sexual').value
   
    let student = {
        fullName: fullName,
        email: email,
        phone: phone,
        sexual: sexual
    }

    // console.log(localStorage)
    var listStudent = localStorage.getItem('key') ? JSON.parse(localStorage.getItem('key')) : []
    listStudent.push(student)
    console.log(listStudent)
    localStorage.setItem('key', JSON.stringify(listStudent))
}

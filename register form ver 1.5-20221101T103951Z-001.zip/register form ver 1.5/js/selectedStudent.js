var selectIndex = []
function processIndexColor() {
    document.getElementById(selectIndex[0]).style.color = 'black'
    document.getElementById(selectIndex[1]).style.color = 'black'
}

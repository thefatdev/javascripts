function checkKeyCode(event) {
    let keyCode = event.which
    switch(keyCode) {
        case 40:
            window.scrollBy(0, 100)
            break;
        case 38:
            window.scrollBy(0, -100)
        case 37:
            window.scrollBy(100, 0)
        case 39:
            window.scrollBy(-100, 0)
    }
}
window.addEventListener('keypress', checkKeyCode)
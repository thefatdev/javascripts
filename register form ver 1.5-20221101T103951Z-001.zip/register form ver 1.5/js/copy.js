function copyUser(index) {
    console.log('running copyUser()')
    renderlistStudent()
    function nowUser() {
        console.log('copied userID: ' + index)

        document.getElementById(index).style.color = 'white'
        // selectedStudent(index);
        let selectedStudent = JSON.parse(localStorage.getItem('key'))
        console.log((selectedStudent[index]).fullName)
        document.getElementById('fullName').value  = (selectedStudent[index]).fullName
        document.getElementById('email').value  = (selectedStudent[index]).email
        document.getElementById('phone').value  = (selectedStudent[index]).phone
        document.getElementById('sexual').value  = (selectedStudent[index]).sexual
    }
    nowUser();
    document.getElementById('submitBtn').style.display = 'block'
    document.getElementById('update').style.display = 'none'

    }

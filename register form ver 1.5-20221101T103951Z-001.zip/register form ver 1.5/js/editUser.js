function editUser(index) {
    console.log('running editUser()')
    // console.log( 'index is' + index)
    if(_.isEmpty(selectIndex)) {
        // console.log(selectIndex)
        selectIndex.push(index)
        // console.log( 'Empty but now selectIndex is ' + selectIndex)
        document.getElementById(index).style.color = 'white'

    } else if(selectIndex.length == 1) {
        selectIndex.push(index)
        // console.log(selectIndex)

        // console.log( 'selectIndex has 2 element is '+ selectIndex )
        processIndexColor()
        document.getElementById(selectIndex[1]).style.color = 'white'

    } else {
        processIndexColor()
        selectIndex[1] = index
        // console.log(selectIndex)
        // console.log( 'More than 3 times click edit is '+ selectIndex )
        document.getElementById(selectIndex[1]).style.color = 'white'
    }

    /// change color of selecting row
    

    helloMouse();

///  process

    document.getElementById('submitBtn').style.display = 'none'
    document.getElementById('update').style.display = 'block'

    let listStudent = localStorage.getItem('key') ? JSON.parse(localStorage.getItem('key')) : []
    document.getElementById("fullName").value = listStudent[index].fullName
    document.getElementById("email").value = listStudent[index].email
    document.getElementById("phone").value = listStudent[index].phone
    document.getElementById("sexual").value = listStudent[index].sexual
    document.getElementById("updateStudent").value = index
    // console.log(document.getElementById("updateStudent").value)
    document.getElementById("update").style.display = 'block'
    // updateUSer()
    window.scrollTo(0,0)
}
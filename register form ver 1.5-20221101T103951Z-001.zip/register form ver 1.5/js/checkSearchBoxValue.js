var searchBox = document.getElementById("search")
var studentLookingfor;
//// check fullName searchbox
function checkFullName() {
    /// now start check progress
    console.log('checkFullName()')
    renderlistStudent()
    for (index = 0; index < listStudent.length; index++) {
        if (listStudent[index].fullName == searchBox.value) {
            
            document.getElementById(index).style.color = 'white'
            document.getElementById("searchBoxResult").innerHTML = searchBox.value
            getIndexRowPosition();
        }
    }
}

//  check email search box
function checkEmail() {
    console.log('checkEmail()')
    renderlistStudent()
    for (index = 0; index < listStudent.length; index++) {
        if (listStudent[index].email == searchBox.value) {
            document.getElementById(index).style.color = 'orange'
            document.getElementById("searchBoxResult").innerHTML = searchBox.value
            getIndexRowPosition();
        }
    }
}

/// check phone search bõ
function checkPhone() {
    console.log('checkPhone()')
    renderlistStudent()
    for (index = 0; index < listStudent.length; index++) {
        if (listStudent[index].phone == searchBox.value) {
            console.log(listStudent[index].phone)
            document.getElementById(index).style.color = 'red'
            document.getElementById("searchBoxResult").innerHTML = searchBox.value
            getIndexRowPosition();
        }
    }
}

/////////////////////////////////////////////////////////


function checkSearchBoxValue() {
    if (isFullnameChecked.checked == false) {
        console.log('fullName uncheck')
    } else {
        console.log('fullName checked')
        checkFullName()
    }
    ///////////////////////////////
    // if filter is email
    if (isEmailChecked.checked == false) {
        console.log('email uncheck')
    } else {
        console.log('email checked')
        checkEmail()
    }
    ////////////////
    // if filter is phone
    if (isPhoneChecked.checked == false) {
        console.log('phone uncheck')
    } else {
        console.log('phone checked')
        checkPhone()
    }
}


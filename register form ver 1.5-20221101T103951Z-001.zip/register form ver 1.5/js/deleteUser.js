function deleteUser(index) {
    console.log('running deleteUser()')
    // console.log(index)
    let listStudent = localStorage.getItem('key') ? JSON.parse(localStorage.getItem('key')) : []
    // console.log(listStudent)
    listStudent.splice(index,1)
    // console.log(listStudent)
    localStorage.setItem('key', JSON.stringify(listStudent))
    // console.log(localStorage)
    renderlistStudent()

}
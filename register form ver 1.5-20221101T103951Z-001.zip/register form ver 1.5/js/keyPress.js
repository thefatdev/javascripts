
    var isAnyPressKey = document.querySelector(".form-register")
//// Press Enter then run submit()
    isAnyPressKey.onkeypress = function (event) {
        let keycode = event.which
        if(keycode == 13) {
            let submitBtn = document.getElementById('submitBtn').style.display
            console.log( 'submit la' + submitBtn)
            if(_.isEmpty(submitBtn)) {
                console.log('ban dang bam Enter de submit')
                isConfirmChange()
            } else {
                console.log('ban dang bam Enter de update')
                isConfirmUpdate()
            }

    }
}
//// Target element
    isAnyPressKey.onclick = function (event) {
        console.log(event.target)
    }



/// Press Del then delete targeting field
      /// fullName del key
    var isAnyKeyUpFullName = document.getElementById("fullName")

    isAnyKeyUpFullName.onkeyup = function(e) {
        if(e.keyCode == 8) {
            document.getElementById('fullName').value = ''
        }
    }
      /// email del key
    var isAnyKeyUpEmail = document.getElementById("email")
    isAnyKeyUpEmail.onkeyup = function(e) {
        if(e.keyCode == 8) {
            document.getElementById('email').value = ''
        }
    }
    /// phone del key
    var isAnyKeyUpPhone = document.getElementById("phone")
    isAnyKeyUpPhone.onkeyup = function(e) {
        if(e.keyCode == 8) {
            document.getElementById('phone').value = ''
        }
    }
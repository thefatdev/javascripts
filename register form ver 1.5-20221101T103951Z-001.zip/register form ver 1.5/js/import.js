function importListStudent() {
    console.log('running importListStudent()')
    let alreadyListStudent = [{
        fullName: 'Tran Van A',
        email: 'tranvana@gmail.com',
        phone: '0911212738',
        sexual: 'Nam'
    },
    {
        fullName: 'Tran Thi B',
        email: 'tranthib@gmail.com',
        phone: '0911212766',
        sexual: 'Nu'
    },
    {
        fullName: 'Tran Dang C',
        email: 'trandangc@gmail.com',
        phone: '0911212118',
        sexual: 'Nam'
    },
    {
        fullName: 'Nguyen Thi D',
        email: 'nguyenthid@gmail.com',
        phone: '0911212700',
        sexual: 'Nu'
    },
    {
        fullName: 'Pham Van E',
        email: 'phamvane@gmail.com',
        phone: '0911002738',
        sexual: 'Nam'
    }]

    localStorage.setItem('key', JSON.stringify(alreadyListStudent))
    renderlistStudent();

}


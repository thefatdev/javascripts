function isConfirmChange() {
    console.log('running isConfirmChange()')
    if( confirm('you are saving an new data! Are you sure ?') == true) {
        submitButton()
        console.log('submited')
    } else {
        console.log('no update')
    }
   
}

function syncData() {
    confirm('your data is not up to date, please sync data now!')
}


function isConfirmUpdate() {
    if( confirm('you are updating new information! are you sure?')) {
        updateUSer()
        console.log('updated')
    } else {

    }
}



// 
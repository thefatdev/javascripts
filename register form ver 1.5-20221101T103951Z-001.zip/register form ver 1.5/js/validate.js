function validateForm() {
        console.log('running validateForm()')

        var fullName = document.getElementById('fullName').value
        var email = document.getElementById('email').value
        var phone = document.getElementById('phone').value
        var sexual = document.getElementById('sexual').value



        if (_.isEmpty(fullName)) {
            document.getElementById('errorFullName').innerHTML = 'FullName is Empy'
            document.getElementById('fullName').value = ''
        } else {
            let regexFullName = /(^[a-zA-Z][a-zA-Z\s]{0,20}[a-zA-Z]$)/
            function checkValidateFullname(e) {
                if (e.test(fullName)) {
                    console.log('fullName is Valid')
                    document.getElementById('errorFullName').innerHTML = ''
                    console.log(fullName)
                } else {
                    console.log('fullName is invalid')
                    document.getElementById('errorFullName').innerHTML = 'Invalid Fullname'
                    document.getElementById('fullName').value = ''
                    console.log(document.getElementById('fullName').value)
                }
                // console.log( 'day la e: ' + e)
            }
            checkValidateFullname(regexFullName);

        }
        /////////////

        if (_.isEmpty(email)) {
            document.getElementById('errorEmail').innerHTML = 'Email is Empy'
            document.getElementById('email').value = ''
        } else {
            let regexEmail = /^[a-z][a-z0-9_\.]{5,32}@[a-z0-9]{2,}(\.[a-z0-9]{2,4}){1,2}$/
            function checkValidateEmail(e) {
                if (e.test(email)) {
                    document.getElementById('errorEmail').innerHTML = ''
                    console.log('email valid')
                } else {
                    document.getElementById('errorEmail').innerHTML = 'Invalid Email'
                    document.getElementById('email').value = ''
                    // missInformation()
                }
            }
            checkValidateEmail(regexEmail);
            // console.log('day la email:  ' + document.getElementById('email').value)
        }

        //////////////////////////////////////////

        if (_.isEmpty(phone)) {
            document.getElementById('errorPhone').innerHTML = 'Phone is Empy'
            document.getElementById('phone').value = ''
        } else if (phone.length == 10) {
            console.log(phone.length)
            console.log('phone is valid')
            document.getElementById('errorPhone').innerHTML = ''
        } else {
            console.log('phone must have at least 10 characters')
            document.getElementById('errorPhone').innerHTML = 'Phone must have at least 10 characters'
            document.getElementById('phone').value = ''
        }

        //////////////////////////////////////////

        if (_.isEmpty(sexual)) {
            document.getElementById('errorSexual').innerHTML = 'Sexual is Empy'
            document.getElementById('sexual').value = ''
        } else document.getElementById('errorSexual').innerHTML = ''

        //////////////////////////////////
        if ((document.getElementById('fullName').value) && (document.getElementById('email').value) && (document.getElementById('phone').value) && (document.getElementById('sexual').value) ) {
            console.log('Ok')
            notiAddSuccess();
            addStudentToLocal();
        } else {
            missInformation()
        }


}




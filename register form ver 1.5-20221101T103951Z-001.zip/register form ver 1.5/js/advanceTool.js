// Drag mouse handler

var dragHeaderAdvanceTool = document.getElementById('headerAdvanceTool')
dragHeaderAdvanceTool.onmousedown = mouseDown;
var addvanceTool = document.getElementById("addvanceTool")

var pos1 = 0;  //x
var pos2 = 0;  //y
var pos3 = 0;  //x
var pos4 = 0;  //y

function mouseDown(e) {
    e = e || window.event
    e.preventDefault()
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmousemove = mouseDrag
    document.onmouseup = mouseUp
}


function mouseDrag(e) {
    e = e || window.event
    e.preventDefault()
    // set new mouse position 
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;
    addvanceTool.style.top = (addvanceTool.offsetTop - pos2) + "px";
    addvanceTool.style.left = (addvanceTool.offsetLeft - pos1) + "px";
}


function mouseUp() {
    document.onmousemove = null
    document.onmouseup = null
}

// ------------------------------------ //
// show or hide advance filter
var advanceFilter = document.getElementById("advancebtn")
var fieldFilter = document.querySelector('.fieldFilter').style
advanceFilter.onclick = advanceFilterHandler
function advanceFilterHandler() {
    // console.log()
    if (fieldFilter.display === 'block') {
        // console.log('fieldFilter is Block now will change to none')
        fieldFilter.display = 'none'
    } else {
        // console.log('fieldFilter is none now will change to block')
        fieldFilter.display = 'block'
    }
}

/// handle filter sexual 

// if choose sexual value = Nam

var selectSexual = document.getElementById("selectSexual")
selectSexual.onclick = chooseSexualHandler
function chooseSexualHandler() {
    // console.log((selectSexual[selectSexual.selectedIndex]).value)

}

//// get list student Nam
var listStudent = localStorage.getItem('key') ? JSON.parse(localStorage.getItem('key')) : []
// console.log(listStudent)
var listNam = []
var listNu = []
// console.log( 'listNam: ' + typeof listNam)

var listNam = []
var listNu = []
/// create lsitNam & listNu student
function listSexual(index) {
    renderlistStudent()
    for(index=0; index<listStudent.length; index++) {
        if(listStudent[index].sexual == 'Nam') {
            listNam.push(listStudent[index])
            console.log('listNam is: '+ listNam)
        } else {
            listNu.push(listStudent[index])
            console.log('listNu is: ' + listNu)
        }
    }
}

/// check student exist or not in listNam or listNu
function checkExistStudent() {
    if()
}




function hideSexualNu(index) {
    console.log('running testFilter()')
    renderlistStudent()
    for (index = 0; index < listStudent.length; index++) {
        if (listStudent[index].sexual == 'Nu') {
            
            console.log('Student: ' + index)
            console.log(document.getElementById(index))
            document.getElementById(index).style.display = 'none'
        }

    }

}



function hideSexualNam(index) {
    console.log('running testFilter()')
    renderlistStudent()
    for (index = 0; index < listStudent.length; index++) {
        if (listStudent[index].sexual == 'Nam') {
            console.log('Student: ' + index)
            console.log(document.getElementById(index))
            document.getElementById(index).style.display = 'none'
        }

    }
}

// define index element position 
function getIndexRowPosition() {
    var indexRowPosition = document.getElementById(index)
    console.log('index position is: ' + indexRowPosition.offsetTop + 'right' + indexRowPosition.offsetLeft)
    window.scrollTo(indexRowPosition.offsetLeft + 20, indexRowPosition.offsetTop + 20)
}



var isFullnameChecked = document.getElementById("fullName-field")
var isEmailChecked = document.getElementById("email-field")
var isPhoneChecked = document.getElementById("phone-field")

/// search button process
var searchbtn = document.getElementById("searchbtn")
searchbtn.onclick = searchbtnHandler
function searchbtnHandler() {
    console.log('searchbtnHandler')
    console.log(searchBox.value)
    listSexual()
    // if ((selectSexual[selectSexual.selectedIndex]).value == 'Nam') {
    //     hideSexualNu()
    // } else if((selectSexual[selectSexual.selectedIndex]).value == 'Nu'){
    //     hideSexualNam()
    // } else {
    //     renderlistStudent()
    // }

    // checkSearchBoxValue()

}
var resetForm = document.getElementById('refreshButton')

function handleResetForm() {
    console.log('running handleResetForm()')
    document.getElementById('fullName').value = ''
    document.getElementById('email').value = ''
    document.getElementById('phone').value = ''
    document.getElementById('sexual').value = ''
    document.getElementById('submitBtn').style.display = 'block'
    document.getElementById('update').style.display = 'none'
}

resetForm.addEventListener("click", handleResetForm)
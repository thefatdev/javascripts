// window.addEventListener('scroll', () => {
// const windowScrollPosition = window.screenLeft
//     console.log(windowScrollPosition)
// })



function notiAddSuccess() {
    document.getElementById("missInformation").innerHTML = 'Added successfull !'
    document.getElementById("missInformation").style.color = 'yellow'
    document.querySelector(".notification").style.display = 'block'
}

function missInformation() {
    document.getElementById("submitSuccess").innerHTML = 'Information is invalid ! cannot add !'
    document.getElementById("submitSuccess").style.color = 'white'
    document.querySelector(".notification").style.display = 'block'
}

//////////////////////////////////////////////////////////////////////////////////

function submitButton() {

    validateForm()
    renderlistStudent()

}
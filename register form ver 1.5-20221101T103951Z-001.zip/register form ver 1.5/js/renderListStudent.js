function renderlistStudent() {
    console.log('running renderlistStudent()')
    var listStudent = localStorage.getItem('key') ? JSON.parse(localStorage.getItem('key')) : []
    // console.log(listStudent)
    // console.log(listStudent.splice(3,1))
    // console.log(listStudent)

    var tableinfo = 
    `
    <tr>
    <th class="stt">STT</th>
    <th class="title">Full Name</th>
    <th class="title">Email</th>
    <th class="title">phone</th>
    <th class="title">Gioi Tinh</th>
    <th class="title">Action</th>
</tr>
    `
    listStudent.map(function(value, index){
        // console.log(value)
        tableinfo += ` 
        <tr id="${index}">
    <td class="stt">${index + 1}</td>
    <td class="title">${value.fullName}</td>
    <td class="title">${value.email}</td>
    <td class="title">${value.phone}</td>
    <td class="title">${value.sexual}</td>
    <td class="title"> <button onclick="editUser(${index})" class="editThisUser"> Edit </button> | <button onclick="deleteUser(${index})"> Delete </button> | <button onclick="copyUser(${index})">Copy</button> </td>
</tr>
        `
    })

    document.getElementById('table-info').innerHTML = tableinfo
}
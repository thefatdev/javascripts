var mousePosition = []
function helloMouse() {
    console.log(mousePosition)
    console.log('running helloMouse()')
    let clientX = event.clientX;
    let clientY = event.clientY;
    if(_.isEmpty(mousePosition)) {
        mousePosition.push(clientX,clientY)
    } else {
        mousePosition = []
        mousePosition.push(clientX,clientY)
    }
    console.log( 'mousePosition is: ' + mousePosition)
}
function clearListStudent() {
    console.log('running clearListStudent()')
    console.log('All student cleared')
    localStorage.clear()
    renderlistStudent()
}
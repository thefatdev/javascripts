function updateUSer() {

        console.log('running updateUSer()')
    let listStudent = localStorage.getItem('key') ? JSON.parse(localStorage.getItem('key')) : []
    let indexChange = document.getElementById("updateStudent").value
    // console.log(indexChange)
    // console.log('list1' +  JSON.stringify(listStudent))
    listStudent[indexChange] = {
        fullName: document.getElementById("fullName").value,
        email: document.getElementById("email").value,
        phone: document.getElementById("phone").value,
        sexual: document.getElementById("sexual").value
    }

    // console.log(listStudent[indexChange])
    // console.log(JSON.stringify(listStudent))
    // console.log('list2' +  JSON.stringify(listStudent))
    localStorage.setItem('key', JSON.stringify(listStudent))
    renderlistStudent()
    //clear form
    document.getElementById("fullName").value = ''
    document.getElementById("email").value = ''
    document.getElementById("phone").value = ''
    document.getElementById("sexual").value = ''
    // hidden button
    document.getElementById('update').style.display = 'none'
    document.getElementById('submitBtn').style.display = 'block'
    window.scrollTo(mousePosition[0]+20,(mousePosition[1]+10))
    console.log('update Position is + '+ mousePosition[0], mousePosition[1])
}